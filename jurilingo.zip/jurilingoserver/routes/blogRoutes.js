import express from 'express';
import Blog from '../models/Blog.js';

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { title, author, content, imageUrl } = req.body;

    if (!title || !author || !content) {
      return res.status(400).json({
        success: false,
        message: 'Title, author, and content are required',
      });
    }

    const blog = await Blog.create({
      title,
      author,
      content,
      imageUrl: imageUrl || '',
    });

    return res.status(201).json({
      success: true,
      message: 'Blog created successfully',
      blog,
    });
  } catch (error) {
    console.error('Error creating blog:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while creating blog',
    });
  }
});


router.get('/recent', async (req, res) => {
  try {
    const blogs = await Blog.find()
      .sort({ createdAt: -1 })
      .limit(3);

    return res.status(200).json({
      success: true,
      blogs,
    });
  } catch (error) {
    console.error('Error fetching recent blogs:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching recent blogs',
    });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const blog = await Blog.findById(id);

    if (!blog) {
      return res.status(404).json({
        success: false,
        message: 'Blog not found',
      });
    }

    return res.status(200).json({
      success: true,
      blog,
    });
  } catch (error) {
    console.error('Error fetching blog by id:', error);
    // If the id is invalid ObjectId, this will also catch that
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching blog',
    });
  }
});

export default router;
