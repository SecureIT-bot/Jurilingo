import express from 'express';
import Competition from '../models/Competition.js';

const router = express.Router();

/**
 * 1. Create a competition
 * POST /api/competitions
 */
router.post('/', async (req, res) => {
  try {
    const {
      title,
      description,
      registrationFee,
      date,
      startDate,
      endDate,
      status,
      participants,
    } = req.body;

    if (!title || !startDate || !endDate) {
      return res.status(400).json({
        success: false,
        message: 'Title, startDate, and endDate are required',
      });
    }

    const competition = await Competition.create({
      title,
      description,
      registrationFee,
      date,
      startDate,
      endDate,
      status: status || 'active',
      participants: participants || [],
    });

    return res.status(201).json({
      success: true,
      message: 'Competition created successfully',
      competition,
    });
  } catch (error) {
    console.error('Error creating competition:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while creating competition',
    });
  }
});

/**
 * 2. Fetch a competition by competition id
 * GET /api/competitions/:id
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const competition = await Competition.findById(id).populate('participants');

    if (!competition) {
      return res.status(404).json({
        success: false,
        message: 'Competition not found',
      });
    }

    return res.status(200).json({
      success: true,
      competition,
    });
  } catch (error) {
    console.error('Error fetching competition by id:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching competition',
    });
  }
});

/**
 * 3. Fetch competitions by user_id
 *    (all competitions where user is a participant)
 * GET /api/competitions/user/:userId
 */
router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const competitions = await Competition.find({
      participants: userId, // mongoose will cast to ObjectId
    })
      .sort({ endDate: 1 }) // soonest ending first
      .populate('participants');

    return res.status(200).json({
      success: true,
      competitions,
    });
  } catch (error) {
    console.error('Error fetching competitions by user:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching competitions for user',
    });
  }
});

/**
 * 4. Fetch all active and inactive competitions ordered by end date
 * GET /api/competitions/status/all
 */
router.get('/status/all/list', async (req, res) => {
  try {
    // explicitly filter for active/inactive in case you add more statuses later
    const competitions = await Competition.find({
      status: { $in: ['active', 'inactive'] },
    }).sort({ endDate: 1 }); // ascending by endDate

    return res.status(200).json({
      success: true,
      competitions,
    });
  } catch (error) {
    console.error('Error fetching competitions by status:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching competitions',
    });
  }
});

/**
 * 5. Fetch all active competitions ordered by end date
 * GET /api/competitions/status/active
 */
router.get('/status/active/list', async (req, res) => {
  try {
    const competitions = await Competition.find({
      status: 'active',
    }).sort({ endDate: 1 });

    return res.status(200).json({
      success: true,
      competitions,
    });
  } catch (error) {
    console.error('Error fetching active competitions:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching active competitions',
    });
  }
});



/**
 * 6. Register a user for a competition
 * POST /api/competitions/:competitionId/register
 */
router.post('/:competitionId/register', async (req, res) => {
  try {
    const { competitionId } = req.params;
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: 'userId is required',
      });
    }

    // Find competition
    const competition = await Competition.findById(competitionId);

    if (!competition) {
      return res.status(404).json({
        success: false,
        message: 'Competition not found',
      });
    }

    // Check if user already registered
    const isAlreadyRegistered = competition.participants.some(
      (id) => id.toString() === userId
    );

    if (isAlreadyRegistered) {
      return res.status(400).json({
        success: false,
        message: 'User already registered for this competition',
      });
    }

    // Add user
    competition.participants.push(userId);
    await competition.save();

    return res.status(200).json({
      success: true,
      message: 'User successfully registered for the competition',
      competition,
    });
  } catch (error) {
    console.error('Error registering user:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error during registration',
    });
  }
});



export default router;
