import express from 'express';
import Podcast from '../models/podcast.js';

const router = express.Router();

/**
 * POST /api/podcasts
 * Create a new podcast
 */
router.post('/', async (req, res) => {
  try {
    const { title, youtubeUrl } = req.body;

    if (!title || !youtubeUrl) {
      return res.status(400).json({
        success: false,
        message: 'Title and youtubeUrl are required',
      });
    }

    const podcast = await Podcast.create({ title, youtubeUrl });

    return res.status(201).json({
      success: true,
      message: 'Podcast created successfully',
      podcast,
    });
  } catch (error) {
    console.error('Error creating podcast:', error);

    // Handle invalid YouTube URL error from pre('validate')
    if (error.message === 'Invalid YouTube URL') {
      return res.status(400).json({
        success: false,
        message: 'Invalid YouTube URL',
      });
    }

    return res.status(500).json({
      success: false,
      message: 'Server error while creating podcast',
    });
  }
});

/**
 * GET /api/podcasts
 * Get all podcasts (newest first)
 */
router.get('/', async (req, res) => {
  try {
    const podcasts = await Podcast.find().sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      podcasts,
    });
  } catch (error) {
    console.error('Error fetching podcasts:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching podcasts',
    });
  }
});

/**
 * GET /api/podcasts/:id
 * Get a single podcast by ID
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const podcast = await Podcast.findById(id);

    if (!podcast) {
      return res.status(404).json({
        success: false,
        message: 'Podcast not found',
      });
    }

    return res.status(200).json({
      success: true,
      podcast,
    });
  } catch (error) {
    console.error('Error fetching podcast by id:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching podcast',
    });
  }
});

/**
 * PATCH /api/podcasts/:id
 * Update a podcast (title and/or youtubeUrl)
 */
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, youtubeUrl } = req.body;

    const podcast = await Podcast.findById(id);

    if (!podcast) {
      return res.status(404).json({
        success: false,
        message: 'Podcast not found',
      });
    }

    if (title !== undefined) podcast.title = title;
    if (youtubeUrl !== undefined) podcast.youtubeUrl = youtubeUrl; // pre('validate') will update youtubeId

    await podcast.save();

    return res.status(200).json({
      success: true,
      message: 'Podcast updated successfully',
      podcast,
    });
  } catch (error) {
    console.error('Error updating podcast:', error);

    if (error.message === 'Invalid YouTube URL') {
      return res.status(400).json({
        success: false,
        message: 'Invalid YouTube URL',
      });
    }

    return res.status(500).json({
      success: false,
      message: 'Server error while updating podcast',
    });
  }
});

/**
 * DELETE /api/podcasts/:id
 * Delete a podcast
 */
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const podcast = await Podcast.findByIdAndDelete(id);

    if (!podcast) {
      return res.status(404).json({
        success: false,
        message: 'Podcast not found',
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Podcast deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting podcast:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while deleting podcast',
    });
  }
});

export default router;
