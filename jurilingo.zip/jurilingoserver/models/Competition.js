import mongoose from 'mongoose';

const CompetitionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: String,
  registrationFee: Number,

  
  date: {
    type: Date,
    default: Date.now,
  },

  
  startDate: {
    type: Date,
    required: true,
  },
  endDate: {
    type: Date,
    required: true,
  },

  
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active',
  },

  participants: [
    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  ],
});


export default mongoose.models.Competition || mongoose.model('Competition', CompetitionSchema);