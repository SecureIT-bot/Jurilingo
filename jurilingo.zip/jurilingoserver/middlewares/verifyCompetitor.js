const verifyCompetitor = (req, res, next) => {
  if (req.role !== "competitor") {
    return res.status(403).json({ message: "Forbidden: Competitor access required" });
  }
  next();
};

export default verifyCompetitor;