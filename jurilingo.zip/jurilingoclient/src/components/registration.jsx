import React, { useState } from 'react';
import { Scale } from 'lucide-react';

const Registration = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const colors = {
    teal: '#005F63',
    gold: '#E3B65B',
    bg: '#F5F5F0', // Beige background
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('--- Registration Details ---');
    console.log(formData);
    alert(`Registration details printed to console:\n\nName: ${formData.fullName}\nEmail: ${formData.email}\nPhone: ${formData.phone}`);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center py-12 px-4" style={{ backgroundColor: colors.bg }}>
      
      {/* Icon Header */}
      <div className="mb-6">
        <Scale size={48} style={{ color: colors.gold }} />
      </div>

      <div className="text-center mb-8">
        <h2 className="text-3xl font-extrabold text-[#002B36] mb-2">Create your account</h2>
        <p className="text-[#C59D5F] font-medium">Or sign in if you already have an account</p>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-md bg-white rounded-lg shadow-md p-8">
        <h3 className="text-xl font-bold text-[#002B36] mb-6">Account Information</h3>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Full Name */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
            <input 
              type="text" 
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              placeholder=""
              required
            />
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
            <input 
              type="email" 
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              placeholder=""
              required
            />
          </div>

          {/* Phone Number (New Field) */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Phone Number</label>
            <input 
              type="tel" 
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              placeholder=""
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Password</label>
            <input 
              type="password" 
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              placeholder=""
              required
            />
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Confirm Password</label>
            <input 
              type="password" 
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              placeholder=""
              required
            />
          </div>

          {/* Submit Button */}
          <button 
            type="submit"
            className="w-full py-3 rounded font-bold text-white text-lg mt-4 hover:brightness-110 transition-all shadow-sm"
            style={{ backgroundColor: colors.teal }}
          >
            Register
          </button>
        </form>

        {/* Footer Links */}
        <div className="mt-8 text-center text-sm text-gray-500 border-t pt-6">
          <p>By registering, you agree to our</p>
          <div className="flex justify-center gap-1 mt-1">
            <a href="#" style={{ color: colors.gold }} className="hover:underline">Terms of Service</a>
            <span>and</span>
            <a href="#" style={{ color: colors.gold }} className="hover:underline">Privacy Policy</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Registration;