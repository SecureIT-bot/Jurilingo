// src/components/Footer.jsx
import React from 'react';
import {
  Scale,
  Facebook,
  Twitter,
  Linkedin,
  Mail,
  Phone,
  MapPin,
} from 'lucide-react';

const Footer = () => {
  const colors = {
    teal: '#005F63',
    gold: '#E3B65B',
  };

  return (
    <footer
      className="w-full text-white pt-16 pb-8"
      style={{ backgroundColor: colors.teal }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Top Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Column 1: Brand Info */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-3">
              <Scale size={32} style={{ color: colors.gold }} />
              <span className="text-2xl font-bold font-serif">JuriLingo</span>
            </div>
            <p className="text-white/80 leading-relaxed text-sm">
              Connecting moot court competitors, judges, and organizers in one
              comprehensive platform.
            </p>
            <div className="flex gap-4 mt-2">
              <a
                href="#"
                className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors text-white"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors text-white"
              >
                <Twitter size={20} />
              </a>
              <a
                href="#"
                className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors text-white"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3
              className="text-lg font-bold mb-6"
              style={{ color: colors.gold }}
            >
              Quick Links
            </h3>
            <ul className="space-y-4 text-sm">
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Moots
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  About JuriLingo
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Meet the Team
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Register
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Resources */}
          <div>
            <h3
              className="text-lg font-bold mb-6"
              style={{ color: colors.gold }}
            >
              Resources
            </h3>
            <ul className="space-y-4 text-sm">
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  FAQ
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Blog
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Terms of Service
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Us */}
          <div>
            <h3
              className="text-lg font-bold mb-6"
              style={{ color: colors.gold }}
            >
              Contact Us
            </h3>
            <ul className="space-y-6 text-sm">
              <li className="flex items-center gap-3">
                <Mail size={18} style={{ color: colors.gold }} />
                <span className="text-white/90">info@jurilingo.com</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} style={{ color: colors.gold }} />
                <span className="text-white/90">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin
                  size={20}
                  style={{ color: colors.gold }}
                  className="mt-0.5"
                />
                <span className="text-white/90 leading-relaxed">
                  123 Legal Avenue, Suite 500
                  <br />
                  New York, NY 10001
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 text-center text-sm text-white/60">
          <p>&copy; 2025 JuriLingo. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
