// src/components/navbar.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Scale, ChevronDown, Menu, X } from 'lucide-react';

/**
 * JuriLingo Navbar Component
 * Pure UI component with navigation links.
 */
const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);

  const colors = {
    teal: '#005F63',
    gold: '#E3B65B',
  };

  const navLinks = [
    { name: 'Moots', href: '#moots' },   // still in-page sections for now
    { name: 'Blogs', href: '#blogs' },
  ];

  return (
    <nav
      className="w-full px-4 md:px-8 py-3 shadow-md relative z-50"
      style={{ backgroundColor: colors.teal }}
    >
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        {/* --- LOGO SECTION --- */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative">
            <Scale
              size={36}
              strokeWidth={2}
              style={{ color: colors.gold }}
              className="transform group-hover:scale-110 transition-transform duration-300"
            />
          </div>
          <div className="flex flex-col">
            <h1 className="text-white font-bold text-2xl leading-tight tracking-tight font-serif">
              JuriLingo
            </h1>
            <span
              className="text-xs font-medium tracking-wide"
              style={{ color: colors.gold }}
            >
              Unlocking the Language of Justice
            </span>
          </div>
        </Link>

        {/* --- DESKTOP NAVIGATION --- */}
        <div className="hidden md:flex items-center gap-8">
          {/* Standard Links (still anchor tags to sections) */}
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-lg font-medium text-white transition-colors duration-200 hover:text-opacity-80 hover:text-[#E3B65B]"
            >
              {link.name}
            </a>
          ))}

          {/* About Dropdown */}
          <div className="relative group">
            <button
              onClick={() => setIsAboutOpen(!isAboutOpen)}
              onMouseEnter={() => setIsAboutOpen(true)}
              className="flex items-center gap-1 text-lg font-medium text-white hover:text-opacity-80 transition-colors focus:outline-none"
            >
              About
              <ChevronDown
                size={18}
                className={`transition-transform duration-200 ${
                  isAboutOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Dropdown Menu */}
            {isAboutOpen && (
              <div
                className="absolute top-full right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 animate-in fade-in slide-in-from-top-2 duration-200"
                onMouseLeave={() => setIsAboutOpen(false)}
              >
                <a
                  href="#story"
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100"
                >
                  Our Story
                </a>
                <a
                  href="#team"
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100"
                >
                  The Team
                </a>
                <a
                  href="#careers"
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100"
                >
                  Careers
                </a>
              </div>
            )}
          </div>

          {/* Auth Buttons */}
          <div className="flex items-center gap-6 ml-4">
            <Link
              to="/login"
              className="text-white text-lg font-medium hover:underline decoration-[#E3B65B] decoration-2 underline-offset-4"
            >
              Login
            </Link>

            <Link
              to="/register"
              className="px-6 py-2 rounded-md font-bold text-lg shadow-sm hover:shadow-md transform hover:-translate-y-0.5 transition-all duration-200 inline-block"
              style={{ backgroundColor: colors.gold, color: colors.teal }}
            >
              Register
            </Link>
          </div>
        </div>

        {/* --- MOBILE BURGER MENU --- */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-white"
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* --- MOBILE DROPDOWN --- */}
      {isMobileMenuOpen && (
        <div className="md:hidden pt-4 pb-6 border-t border-[#ffffff20] mt-2 space-y-4 animate-in slide-in-from-top-5">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="block w-full text-left px-2 text-white text-lg font-medium hover:text-[#E3B65B]"
            >
              {link.name}
            </a>
          ))}

          <div className="px-2 text-white text-lg font-medium">
            <span className="opacity-75 text-sm uppercase tracking-wider mb-2 block">
              About
            </span>
            <div className="pl-4 border-l-2 border-[#E3B65B] space-y-2">
              <a
                href="#story"
                className="block w-full text-left text-base py-1 hover:text-[#E3B65B]"
              >
                Our Story
              </a>
              <a
                href="#team"
                className="block w-full text-left text-base py-1 hover:text-[#E3B65B]"
              >
                The Team
              </a>
            </div>
          </div>

          <div className="pt-4 flex flex-col gap-3 px-2">
            <Link
              to="/login"
              className="w-full py-2 text-white border border-white rounded text-center hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Login
            </Link>
            <Link
              to="/register"
              className="w-full py-2 font-bold rounded text-center"
              style={{ backgroundColor: colors.gold, color: colors.teal }}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Register
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
