import React, { useState } from 'react';
import { Scale } from 'lucide-react';
import { Link } from 'react-router-dom';

const Login = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const colors = {
    teal: '#005F63',
    gold: '#E3B65B',
    bg: '#F5F5F0',
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('--- Login Details ---');
    console.log(formData);
    alert(`Login attempted for:\nEmail: ${formData.email}`);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center py-12 px-4" style={{ backgroundColor: colors.bg }}>
      
      {/* Icon Header */}
      <div className="mb-6">
        <Scale size={48} style={{ color: colors.gold }} />
      </div>

      <div className="text-center mb-8">
        <h2 className="text-3xl font-extrabold text-[#002B36] mb-2">Sign in to your account</h2>
        <button 
          onClick={() => onNavigate('register')}
          className="text-[#C59D5F] font-medium hover:underline"
        >
          Or create a new account
        </button>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-md bg-white rounded-lg shadow-md p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Email Address */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
            <input 
              type="email" 
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              required
            />
          </div>

          {/* Password with Forgot Link */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-sm font-bold text-gray-700">Password</label>
              <a href="#" className="text-sm font-medium text-[#005F63] hover:underline">Forgot password?</a>
            </div>
            <input 
              type="password" 
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#005F63] focus:border-transparent transition-all"
              required
            />
          </div>

          {/* Submit Button */}
          <button 
            type="submit"
            className="w-full py-3 rounded font-bold text-white text-lg mt-2 hover:brightness-110 transition-all shadow-sm"
            style={{ backgroundColor: colors.teal }}
          >
            Sign in
          </button>
        </form>

        {/* Footer Link */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>
            Don't have an account?{' '}
            <button 
              className="font-bold text-[#005F63] hover:underline"
            >
              Register now
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;