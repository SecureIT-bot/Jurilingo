import { Routes, Route } from 'react-router-dom';

import './App.css';
import Navbar from './components/navbar.jsx';
import Hero from './components/hero.jsx';
import Features from './components/features.jsx';
import CTASection from './components/ctasection.jsx';
import Footer from './components/footer.jsx';
import Registration from './components/registration.jsx';
import Login from './components/login.jsx';

function App() {
  const HomePage = () => (
    <>
      <Hero />
      <Features />
      <CTASection />
    </>
  );

  return (
    <div className="min-h-screen font-sans bg-gray-50 flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;
