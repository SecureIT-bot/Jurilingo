var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/f8583_5e868f58._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/Code/jurilingo/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Code/jurilingo/node_modules/next/document.js [ssr] (ecmascript)").exports
