module.exports = [
"[project]/Code/jurilingo/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Code_jurilingo__next-internal_server_app_page_actions_5ae21be5.js.map