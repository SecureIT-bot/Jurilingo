module.exports = [
"[project]/Code/jurilingo/.next-internal/server/app/blogs/upload/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Code_jurilingo__next-internal_server_app_blogs_upload_page_actions_d0dd04e8.js.map