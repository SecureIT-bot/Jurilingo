module.exports = [
"[project]/Code/jurilingo/.next-internal/server/app/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Code_jurilingo__next-internal_server_app_register_page_actions_2739b6c4.js.map