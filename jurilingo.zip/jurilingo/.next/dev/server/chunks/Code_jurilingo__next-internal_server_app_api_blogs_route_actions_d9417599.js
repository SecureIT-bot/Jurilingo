module.exports = [
"[project]/Code/jurilingo/.next-internal/server/app/api/blogs/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Code_jurilingo__next-internal_server_app_api_blogs_route_actions_d9417599.js.map