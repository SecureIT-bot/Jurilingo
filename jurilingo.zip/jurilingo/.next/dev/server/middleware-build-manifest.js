globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/f8583_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2e921a21._.js",
    "static/chunks/f8583_next_dist_compiled_react-dom_3b67cdf7._.js",
    "static/chunks/f8583_next_dist_compiled_react-server-dom-turbopack_028e81e3._.js",
    "static/chunks/f8583_next_dist_compiled_next-devtools_index_94d636a7.js",
    "static/chunks/f8583_next_dist_compiled_2360ce60._.js",
    "static/chunks/f8583_next_dist_client_b97a851d._.js",
    "static/chunks/f8583_next_dist_0666f72b._.js",
    "static/chunks/f8583_@swc_helpers_cjs_6194595a._.js",
    "static/chunks/Code_jurilingo_a0ff3932._.js",
    "static/chunks/turbopack-Code_jurilingo_e6d96926._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];