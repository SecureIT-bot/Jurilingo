var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/blogs/route.js")
R.c("server/chunks/f8583_next_2fcbedf9._.js")
R.c("server/chunks/[root-of-the-server]__c9354c34._.js")
R.c("server/chunks/Code_jurilingo__next-internal_server_app_api_blogs_route_actions_d9417599.js")
R.m("[project]/Code/jurilingo/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Code/jurilingo/src/app/api/blogs/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Code/jurilingo/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Code/jurilingo/src/app/api/blogs/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
