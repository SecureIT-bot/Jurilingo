__turbopack_load_page_chunks__("/_error", [
  "static/chunks/f8583_next_dist_compiled_3ddc1ee6._.js",
  "static/chunks/f8583_next_dist_shared_lib_75cc0984._.js",
  "static/chunks/f8583_next_dist_client_49df4924._.js",
  "static/chunks/f8583_next_dist_56788d4b._.js",
  "static/chunks/f8583_next_error_10908d84.js",
  "static/chunks/[next]_entry_page-loader_ts_a41291e6._.js",
  "static/chunks/f8583_react-dom_fbad2e29._.js",
  "static/chunks/f8583_961177d2._.js",
  "static/chunks/[root-of-the-server]__a4fb066d._.js",
  "static/chunks/Code_jurilingo_pages__error_2da965e7._.js",
  "static/chunks/turbopack-Code_jurilingo_pages__error_a3971bf4._.js"
])
