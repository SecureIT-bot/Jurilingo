(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Code/jurilingo/node_modules/react-quill/lib/index.js [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/f8583_de5adaba._.js",
  "static/chunks/f8583_react-quill_lib_index_bfe2978d.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Code/jurilingo/node_modules/react-quill/lib/index.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);