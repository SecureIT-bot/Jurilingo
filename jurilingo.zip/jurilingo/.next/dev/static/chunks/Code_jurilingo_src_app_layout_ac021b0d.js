(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5360f05c._.css",
  "static/chunks/Code_jurilingo_fb93d57a._.js"
],
    source: "dynamic"
});
