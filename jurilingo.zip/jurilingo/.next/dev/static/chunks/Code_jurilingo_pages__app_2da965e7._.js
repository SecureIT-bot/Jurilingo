(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f8583_next_dist_compiled_3ddc1ee6._.js",
  "static/chunks/f8583_next_dist_shared_lib_9c0d3c73._.js",
  "static/chunks/f8583_next_dist_client_49df4924._.js",
  "static/chunks/f8583_next_dist_8c32edce._.js",
  "static/chunks/f8583_next_app_6b4a4430.js",
  "static/chunks/[next]_entry_page-loader_ts_49daecb7._.js",
  "static/chunks/f8583_react-dom_fbad2e29._.js",
  "static/chunks/f8583_961177d2._.js",
  "static/chunks/[root-of-the-server]__b90b145a._.js"
],
    source: "entry"
});
