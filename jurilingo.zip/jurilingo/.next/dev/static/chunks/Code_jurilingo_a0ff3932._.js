(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2e921a21._.js",
  "static/chunks/f8583_next_dist_compiled_react-dom_3b67cdf7._.js",
  "static/chunks/f8583_next_dist_compiled_react-server-dom-turbopack_028e81e3._.js",
  "static/chunks/f8583_next_dist_compiled_next-devtools_index_94d636a7.js",
  "static/chunks/f8583_next_dist_compiled_2360ce60._.js",
  "static/chunks/f8583_next_dist_client_b97a851d._.js",
  "static/chunks/f8583_next_dist_0666f72b._.js",
  "static/chunks/f8583_@swc_helpers_cjs_6194595a._.js"
],
    source: "entry"
});
