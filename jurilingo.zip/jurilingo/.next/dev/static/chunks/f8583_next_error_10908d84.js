(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Code/jurilingo/node_modules/next/error.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Code/jurilingo/node_modules/next/dist/pages/_error.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=f8583_next_error_10908d84.js.map