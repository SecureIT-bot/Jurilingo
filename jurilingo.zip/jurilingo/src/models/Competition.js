import mongoose from 'mongoose';

const CompetitionSchema = new mongoose.Schema({
  title: String,
  description: String,
  registrationFee: Number, // For Razorpay
  date: Date,
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
});

export default mongoose.models.Competition || mongoose.model('Competition', CompetitionSchema);