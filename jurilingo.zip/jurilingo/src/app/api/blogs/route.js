import dbConnect from '@/lib/db';
import Blog from '@/models/Blog';
import { NextResponse } from 'next/server';

export async function POST(request) {
  try {
    await dbConnect();
    
    // Parse the incoming JSON data
    const body = await request.json();
    
    // Create a new blog post in MongoDB
    const blog = await Blog.create(body);
    
    return NextResponse.json({ success: true, data: blog }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}


export async function GET() {
  await dbConnect();
  try {
    // Fetch latest 3 blogs, sorted by newest first
    const blogs = await Blog.find({}).sort({ createdAt: -1 }).limit(3);
    return NextResponse.json({ success: true, data: blogs });
  } catch (error) {
    return NextResponse.json({ success: false }, { status: 400 });
  }
}