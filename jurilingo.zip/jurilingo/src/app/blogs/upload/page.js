"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function UploadBlog() {
  // -------------------------
  // AUTH CHECK
  // -------------------------
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    }
  }, [status, router]);

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-brand-teal text-white flex items-center justify-center">
        Loading...
      </div>
    );
  }

  // -------------------------
  // FORM STATE
  // -------------------------
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    imageUrl: "",
    content: "",
  });

  const [submitStatus, setSubmitStatus] = useState("idle"); // idle | loading | success | error
  const [activeTab, setActiveTab] = useState("write");
  const textareaRef = useRef(null);

  // -------------------------
  // EVENT HANDLERS
  // -------------------------
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const updateContent = (newContent) => {
    setFormData((prev) => ({ ...prev, content: newContent }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitStatus("loading");

    try {
      const res = await fetch("/api/blogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) throw new Error("Failed to submit");

      setSubmitStatus("success");
      setFormData({ title: "", author: "", imageUrl: "", content: "" });
    } catch (error) {
      console.error(error);
      setSubmitStatus("error");
    }
  };

  // -------------------------
  // EDITOR TOOLBAR ACTIONS
  // -------------------------
  const applyFormatting = (type) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const { selectionStart, selectionEnd } = textarea;
    const current = formData.content;
    const selectedText = current.slice(selectionStart, selectionEnd) || "";

    let newText = "";
    let before = current.slice(0, selectionStart);
    let after = current.slice(selectionEnd);

    const wrap = (start, end) => `${start}${selectedText || "Your text"}${end}`;

    switch (type) {
      case "bold":
        newText = wrap("**", "**");
        break;
      case "italic":
        newText = wrap("_", "_");
        break;
      case "h1":
        newText = selectedText ? `# ${selectedText}` : "# Heading 1";
        break;
      case "h2":
        newText = selectedText ? `## ${selectedText}` : "## Heading 2";
        break;
      case "quote":
        newText =
          selectedText
            .split("\n")
            .map((line) => `> ${line}`)
            .join("\n") || "> Quoted text";
        break;
      case "code":
        newText = selectedText ? `\`${selectedText}\`` : "`inline code`";
        break;
      case "ul":
        newText =
          selectedText
            .split("\n")
            .map((line) => `- ${line || "List item"}`)
            .join("\n") || "- List item";
        break;
      case "ol":
        newText =
          selectedText
            .split("\n")
            .map((line, idx) => `${idx + 1}. ${line || "List item"}`)
            .join("\n") || "1. List item";
        break;
      default:
        return;
    }

    const updated = before + newText + after;
    updateContent(updated);

    requestAnimationFrame(() => {
      const pos = before.length + newText.length;
      textarea.focus();
      textarea.setSelectionRange(pos, pos);
    });
  };

  // -------------------------
  // WORD COUNT
  // -------------------------
  const wordCount = formData.content.trim()
    ? formData.content.trim().split(/\s+/).length
    : 0;

  const readTime = wordCount ? Math.max(1, Math.round(wordCount / 200)) : 0;

  // -------------------------
  // RENDER
  // -------------------------
  return (
    <div className="min-h-screen bg-brand-teal flex flex-col items-center justify-center p-6 font-sans">
      {/* Back Link */}
      <div className="w-full max-w-4xl mb-6">
        <Link
          href="/"
          className="text-gray-200 hover:text-brand-gold flex items-center gap-2 text-sm font-bold uppercase tracking-wider"
        >
          &larr; Back to Home
        </Link>
      </div>

      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden">
        <div className="bg-brand-dark p-6 text-center">
          <h2 className="text-3xl font-bold text-white">Write a New Blog</h2>
          <p className="text-brand-gold text-sm mt-1">
            Share your legal insights with the community
          </p>
        </div>

        {/* FORM */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              Blog Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="e.g. 5 Tips for Moot Court Researchers"
              className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-brand-teal focus:ring-2 focus:ring-brand-teal/30 transition"
              required
            />
          </div>

          {/* Author + Image URL */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Author Name
              </label>
              <input
                type="text"
                name="author"
                value={formData.author}
                onChange={handleChange}
                placeholder="John Doe"
                className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-brand-teal focus:ring-2 focus:ring-brand-teal/30 transition"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Cover Image URL (Optional)
              </label>
              <input
                type="url"
                name="imageUrl"
                value={formData.imageUrl}
                onChange={handleChange}
                placeholder="https://example.com/image.jpg"
                className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-brand-teal focus:ring-2 focus:ring-brand-teal/30 transition"
              />
            </div>
          </div>

          {/* EDITOR CARD */}
          <div className="border border-gray-200 rounded-xl overflow-hidden">
            {/* Tabs + info */}
            <div className="flex items-center justify-between bg-gray-50 px-4 py-3 border-b border-gray-200">
              <div className="inline-flex items-center rounded-full bg-white p-1 shadow-sm">
                <button
                  type="button"
                  onClick={() => setActiveTab("write")}
                  className={`px-4 py-1 text-xs font-semibold rounded-full transition ${
                    activeTab === "write"
                      ? "bg-brand-teal text-white shadow-sm"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  Write
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("preview")}
                  className={`px-4 py-1 text-xs font-semibold rounded-full transition ${
                    activeTab === "preview"
                      ? "bg-brand-teal text-white shadow-sm"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  Preview
                </button>
              </div>

              <div className="text-xs text-gray-500 flex items-center gap-3">
                <span>{wordCount} words</span>
                {readTime > 0 && <span>· ~{readTime} min read</span>}
              </div>
            </div>

            {/* Toolbar */}
            {activeTab === "write" && (
              <div className="flex flex-wrap gap-2 px-4 py-2 border-b border-gray-200 bg-white text-xs text-gray-600">
                <button
                  type="button"
                  onClick={() => applyFormatting("h1")}
                  className="px-2 py-1 rounded hover:bg-gray-100 font-semibold"
                >
                  H1
                </button>
                <button
                  type="button"
                  onClick={() => applyFormatting("h2")}
                  className="px-2 py-1 rounded hover:bg-gray-100 font-semibold"
                >
                  H2
                </button>
                <span className="w-px h-4 bg-gray-200" />
                <button
                  type="button"
                  onClick={() => applyFormatting("bold")}
                  className="px-2 py-1 rounded hover:bg-gray-100 font-semibold"
                >
                  B
                </button>
                <button
                  type="button"
                  onClick={() => applyFormatting("italic")}
                  className="px-2 py-1 rounded hover:bg-gray-100 italic"
                >
                  I
                </button>
                <button
                  type="button"
                  onClick={() => applyFormatting("code")}
                  className="px-2 py-1 rounded hover:bg-gray-100 font-mono text-[11px]"
                >
                  {"</>"}
                </button>
                <span className="w-px h-4 bg-gray-200" />
                <button
                  type="button"
                  onClick={() => applyFormatting("ul")}
                  className="px-2 py-1 rounded hover:bg-gray-100"
                >
                  • List
                </button>
                <button
                  type="button"
                  onClick={() => applyFormatting("ol")}
                  className="px-2 py-1 rounded hover:bg-gray-100"
                >
                  1. List
                </button>
                <button
                  type="button"
                  onClick={() => applyFormatting("quote")}
                  className="px-2 py-1 rounded hover:bg-gray-100"
                >
                  ❝ Quote
                </button>
              </div>
            )}

            {/* Editor / Preview Section */}
            {activeTab === "write" ? (
              <textarea
                ref={textareaRef}
                name="content"
                value={formData.content}
                onChange={(e) => updateContent(e.target.value)}
                rows={10}
                placeholder="Write your article here..."
                className="w-full p-4 border-none outline-none resize-none text-sm text-gray-800 leading-relaxed placeholder:text-gray-400"
                required
              />
            ) : (
              <div className="p-4 bg-white min-h-[240px] text-sm leading-relaxed text-gray-800 whitespace-pre-wrap">
                {formData.content.trim() ? (
                  formData.content
                ) : (
                  <span className="text-gray-400">
                    Start writing your blog to see a live preview here.
                  </span>
                )}
              </div>
            )}
          </div>

          {/* SUBMIT BUTTON */}
          <button
            type="submit"
            disabled={submitStatus === "loading"}
            className="w-full bg-brand-gold text-brand-teal font-bold py-4 rounded-lg hover:bg-yellow-400 transition shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitStatus === "loading" ? "Publishing..." : "Publish Blog Post"}
          </button>

          {/* STATUS MESSAGES */}
          {submitStatus === "success" && (
            <p className="text-green-600 text-center font-bold bg-green-50 p-3 rounded-lg">
              ✅ Blog published successfully!
            </p>
          )}

          {submitStatus === "error" && (
            <p className="text-red-600 text-center font-bold bg-red-50 p-3 rounded-lg">
              ❌ Something went wrong. Please try again.
            </p>
          )}
        </form>
      </div>
    </div>
  );
}
