"use client";
import { useState, useEffect } from 'react';
import Script from 'next/script';
import Link from 'next/link';

export default function Home() {

  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
  fetch('/api/blogs')
    .then((res) => res.json())
    .then((data) => {
      if (data.success) setBlogs(data.data);
    });
}, []);

  
  // --- Payment Handler (Razorpay) ---
  const handlePayment = async (amount) => {
    // 1. Call your backend to create an order
    const res = await fetch('/api/payment/order', { 
        method: 'POST',
        body: JSON.stringify({ amount })
    });
    const data = await res.json();

    // 2. Open Razorpay Modal
    const options = {
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID, 
      amount: data.amount,
      currency: "INR",
      name: "JuriLingo",
      description: "Competition Registration",
      order_id: data.id, 
      handler: function (response) {
        alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);
        // Call backend here to verify payment and register user in MongoDB
      },
      theme: { color: "#005f63" }
    };

    const rzp1 = new window.Razorpay(options);
    rzp1.open();
  };

  return (
    <div className="min-h-screen bg-brand-teal text-white font-sans selection:bg-brand-gold selection:text-black">
      
      {/* Razorpay Script */}
      <Script src="https://checkout.razorpay.com/v1/checkout.js" />

      {/* --- NAVBAR --- */}
      <nav className="flex justify-between items-center px-8 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
           {/* Logo Icon Placeholder */}
           <div className="text-brand-gold text-2xl">⚖️</div>
           <div className="leading-tight">
             <h1 className="text-xl font-bold tracking-wide">JuriLingo</h1>
             <p className="text-[10px] text-gray-300 uppercase tracking-widest">Unlocking the Language of Justice</p>
           </div>
        </div>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium">
          <Link href="#moots" className="hover:text-brand-gold transition">Moots</Link>
          <Link href="#blogs" className="hover:text-brand-gold transition">Blogs</Link>
          <button className="flex items-center gap-1 hover:text-brand-gold transition">
            About
          </button>
          <Link href="/login" className="hover:text-brand-gold transition">Login</Link>
          <Link href="/register" className="bg-brand-gold text-brand-teal px-5 py-2 rounded font-bold hover:bg-yellow-400 transition shadow-lg">
            Register
          </Link>
        </div>
      </nav>

      {/* --- HERO SECTION (Matching Image) --- */}
      <header className="max-w-7xl mx-auto px-8 mt-20 md:mt-32 pb-20">
        <h2 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight max-w-4xl">
          The Premier Marketplace for Moot Court Competitions
        </h2>
        <p className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl leading-relaxed">
          Connect with prestigious competitions, talented judges, and passionate competitors in one comprehensive platform.
        </p>
        
        <div className="flex gap-4">
          <button className="bg-white text-brand-teal px-8 py-3 rounded font-bold hover:bg-gray-100 transition shadow-md">
            Browse Moots
          </button>
          <button className="bg-brand-gold text-brand-teal px-8 py-3 rounded font-bold hover:bg-yellow-400 transition shadow-md">
            Join JuriLingo
          </button>
        </div>
      </header>

      {/* --- FUNCTIONALITY DEMO SECTIONS --- */}
      
      {/* 1. YouTube Podcast Section */}
      <section className="bg-white text-brand-teal py-16 px-8">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold mb-8">🎙️ Latest from the Podcast</h3>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden shadow-xl">
               <iframe 
                 className="w-full h-full" 
                 src="https://www.youtube.com/embed/dQw4w9WgXcQ" // Replace with your link
                 title="YouTube video player" 
                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                 allowFullScreen>
               </iframe>
            </div>
            <div>
              <h4 className="text-2xl font-bold mb-4">Mastering the Art of Oral Arguments</h4>
              <p className="mb-6 text-gray-600">Join us as we interview supreme court advocates on how to win your next moot.</p>
              <button className="text-brand-teal font-bold border-b-2 border-brand-teal">Listen on YouTube &rarr;</button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Competitions & Payment Section */}
      <section className="bg-gray-50 text-gray-800 py-16 px-8">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold mb-8 text-brand-teal">🏆 Upcoming Competitions</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {/* Card Example */}
            <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition border border-gray-100">
              <div className="bg-brand-teal h-32 rounded mb-4 w-full"></div>
              <h4 className="font-bold text-xl mb-2">National Cyber Law Moot</h4>
              <p className="text-sm text-gray-500 mb-4">Date: Dec 15, 2025</p>
              <div className="flex justify-between items-center mt-4">
                <span className="font-bold text-brand-teal">₹500</span>
                <button 
                  onClick={() => handlePayment(500)}
                  className="bg-brand-teal text-white px-4 py-2 rounded text-sm font-bold hover:bg-brand-dark"
                >
                  Register Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Blogs Section */}
      <div className="grid md:grid-cols-3 gap-6">
        {blogs.map((blog) => (
          <div key={blog._id} className="bg-brand-dark p-6 rounded-lg border border-teal-700 flex flex-col h-full">
            {/* Optional: Display Image if it exists */}
            {blog.imageUrl && (
              <img src={blog.imageUrl} alt={blog.title} className="w-full h-40 object-cover rounded mb-4 opacity-80" />
            )}
            <h4 className="font-bold text-lg mb-2 text-white">{blog.title}</h4>
            <p className="text-xs text-brand-gold mb-2 uppercase tracking-wide">{blog.author}</p>
            <p className="text-sm text-gray-300 mb-4 line-clamp-3 flex-grow">
              {blog.content}
            </p>
            <Link href={`/blogs/${blog._id}`} className="text-brand-gold text-sm font-bold mt-auto inline-block hover:underline">
              Read Full Article &rarr;
            </Link>
          </div>
        ))}
      </div>

    </div>
  );
}