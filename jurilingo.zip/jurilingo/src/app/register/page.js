"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Register() {
  const [info, setInfo] = useState({ name: "", email: "", password: "" });
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("/api/register", {
      method: "POST",
      body: JSON.stringify(info),
    });
    if (res.ok) router.push("/login");
  };

  return (
    <div className="min-h-screen bg-brand-teal flex items-center justify-center p-6">
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 className="text-3xl font-bold text-brand-teal mb-6 text-center">Join JuriLingo</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
            type="text" placeholder="Full Name" required 
            className="w-full p-3 border rounded"
            onChange={e => setInfo({...info, name: e.target.value})}
          />
          <input 
            type="email" placeholder="Email Address" required 
            className="w-full p-3 border rounded"
            onChange={e => setInfo({...info, email: e.target.value})}
          />
          <input 
            type="password" placeholder="Password" required 
            className="w-full p-3 border rounded"
            onChange={e => setInfo({...info, password: e.target.value})}
          />
          <button className="w-full bg-brand-gold text-brand-teal font-bold py-3 rounded hover:bg-yellow-400">
            Register
          </button>
        </form>
        <p className="mt-4 text-center text-sm">
          Already have an account? <Link href="/login" className="text-brand-teal font-bold">Login</Link>
        </p>
      </div>
    </div>
  );
}