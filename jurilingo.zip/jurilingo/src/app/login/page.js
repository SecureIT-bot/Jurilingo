"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const [info, setInfo] = useState({ email: "", password: "" });
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await signIn("credentials", {
      email: info.email,
      password: info.password,
      redirect: false,
    });

    if (res.error) {
      alert("Invalid Credentials");
      return;
    }
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-brand-teal flex items-center justify-center p-6">
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 className="text-3xl font-bold text-brand-teal mb-6 text-center">Welcome Back</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
            type="email" placeholder="Email" required 
            className="w-full p-3 border rounded"
            onChange={e => setInfo({...info, email: e.target.value})}
          />
          <input 
            type="password" placeholder="Password" required 
            className="w-full p-3 border rounded"
            onChange={e => setInfo({...info, password: e.target.value})}
          />
          <button className="w-full bg-brand-gold text-brand-teal font-bold py-3 rounded hover:bg-yellow-400">
            Login
          </button>
        </form>
        <p className="mt-4 text-center text-sm">
          New to JuriLingo? <Link href="/register" className="text-brand-teal font-bold">Register</Link>
        </p>
      </div>
    </div>
  );
}